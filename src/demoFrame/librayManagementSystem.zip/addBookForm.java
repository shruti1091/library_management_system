package demoFrame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

public class addBookForm extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField ISBN;
	private JTextField book_code;
	private JTextField title;
	private JTextField author;
	private JTextField availability;
	private JTextField shelf_no;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addBookForm frame = new addBookForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addBookForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 605);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add Book Form");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(176, 41, 132, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ISBN");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(77, 100, 49, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Book code");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(71, 150, 96, 20);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Category");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(74, 200, 79, 20);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Title");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(74, 300, 79, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Author");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(74, 350, 64, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Availability");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(71, 400, 96, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Shelf number");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(77, 450, 113, 14);
		contentPane.add(lblNewLabel_7);
		
		ISBN = new JTextField();
		ISBN.setBounds(248, 100, 154, 20);
		contentPane.add(ISBN);
		ISBN.setColumns(10);
		
		book_code = new JTextField();
		book_code.setBounds(248, 150, 154, 20);
		contentPane.add(book_code);
		book_code.setColumns(10);
		
		title = new JTextField();
		title.setColumns(10);
		title.setBounds(248, 300, 154, 20);
		contentPane.add(title);
		
		author = new JTextField();
		author.setColumns(10);
		author.setBounds(248, 350, 154, 20);
		contentPane.add(author);
		
		availability = new JTextField();
		availability.setColumns(10);
		availability.setBounds(248, 400, 154, 20);
		contentPane.add(availability);
		
		shelf_no = new JTextField();
		shelf_no.setColumns(10);
		shelf_no.setBounds(248, 450, 154, 20);
		contentPane.add(shelf_no);
		
		final JRadioButton instOnlyButton = new JRadioButton("for instructors only");
		instOnlyButton.setBounds(248, 200, 132, 23);
		contentPane.add(instOnlyButton);
		
		final JRadioButton toLendButton = new JRadioButton("To Lend");
		toLendButton.setBounds(248, 230, 111, 23);
		contentPane.add(toLendButton);
		
		final JRadioButton libUseButton = new JRadioButton("in library use only");
		libUseButton.setBounds(248, 260, 132, 23);
		contentPane.add(libUseButton);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
	                	Class.forName("com.mysql.cj.jdbc.Driver");
	                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/l", "root", "harishruti");

	                    String category = null;
	                    if (instOnlyButton.isSelected()) {
	                        category = "for instructors only";
	                    } else if (toLendButton.isSelected()) {
	                        category = "To Lend";
	                    } else if(libUseButton.isSelected()){
	                        // Handle the case where neither UG nor PG is selected, if needed.
	                        category = "in library use only"; // or set a default value
	                    }

	                    String sql = "INSERT INTO library_books (ISBN, book_code, category, title, author, availability, shelf_no) VALUES (?, ?, ?, ?, ?, ?, ?)";
	                    PreparedStatement pstmt = con.prepareStatement(sql);
	                    pstmt.setString(1, ISBN.getText());
	                    pstmt.setString(2, book_code.getText());
	                    pstmt.setString(3, category);
	                    pstmt.setString(4, title.getText());
	                    pstmt.setString(5, author.getText());
	                    pstmt.setString(6, availability.getText());
	                    pstmt.setString(7, shelf_no.getText());
	                    pstmt.executeUpdate();

	                    JOptionPane.showMessageDialog(null, "Book details added successfully");
	                } catch (Exception ex) {
	                    JOptionPane.showMessageDialog(null, ex.getMessage());
	                }
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(200, 500, 89, 23);
		contentPane.add(btnNewButton);
		
	}
}
