package demoFrame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BookReturnFinePage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField text_isbn;
	private JTextField text_fine;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookReturnFinePage frame = new BookReturnFinePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookReturnFinePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 547, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label_heading = new JLabel("Book Return");
		label_heading.setFont(new Font("Tahoma", Font.PLAIN, 20));
		label_heading.setBounds(215, 63, 115, 33);
		contentPane.add(label_heading);
		
		JLabel label_isbn = new JLabel("ISBN");
		label_isbn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_isbn.setBounds(148, 165, 49, 14);
		contentPane.add(label_isbn);
		
		JLabel label_fine = new JLabel("Fine");
		label_fine.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_fine.setBounds(148, 259, 49, 26);
		contentPane.add(label_fine);
		
		text_isbn = new JTextField();
		text_isbn.setBounds(230, 158, 236, 33);
		contentPane.add(text_isbn);
		text_isbn.setColumns(10);
		
		text_fine = new JTextField();
		text_fine.setBounds(230, 252, 150, 33);
		contentPane.add(text_fine);
		text_fine.setColumns(10);
		
		JButton button_fineCollected = new JButton("Fine Collected");
		button_fineCollected.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				//check other constraits
			}
		});
		button_fineCollected.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button_fineCollected.setBounds(79, 365, 157, 43);
		contentPane.add(button_fineCollected);
		
		JButton button_fineNotCollected = new JButton("Fine Not Collected");
		button_fineNotCollected.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookReturnConstraintsNotMet.main(new String[] {});
			}
		});
		button_fineNotCollected.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button_fineNotCollected.setBounds(289, 365, 157, 43);
		contentPane.add(button_fineNotCollected);
	}

}
