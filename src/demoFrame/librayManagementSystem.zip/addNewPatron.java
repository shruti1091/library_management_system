package demoFrame;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class addNewPatron extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    //private Set<Integer> usedDigits = new HashSet<>();
	private JRadioButton rdbtnNewRadioButton;
	private JRadioButton rdbtnNewRadioButton_1;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    addNewPatron frame = new addNewPatron();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public addNewPatron() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 534, 422);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Enter Patron Name");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel.setBounds(62, 129, 134, 30);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(226, 136, 201, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Select Patron Type");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_2.setBounds(62, 193, 134, 14);
        contentPane.add(lblNewLabel_2);

        JButton btnNewButton = new JButton("Submit");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Receive "name" and "patron type" from the user interface (Swing).
                String name = textField.getText(); // Get the name from the text field
                String patronType = (rdbtnNewRadioButton.isSelected()) ? "Student" : "Faculty"; // Determine patron type based on radio button selection

                // Generate a unique "patron id" in the format "pXXXX"
                //String patronId = generateUniquePatronId();
                
                try {
                	Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb", "root", "harishruti");
                    String sql = "INSERT INTO patron_details (patron_name, user_type) VALUES (?, ?)";
                    PreparedStatement preparedStatement = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
                    preparedStatement.setString(1, name);
                    preparedStatement.setString(2, patronType);

                    int affectedRows = preparedStatement.executeUpdate();

                    if (affectedRows > 0) {
                        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                            if (generatedKeys.next()) {
                                int id = generatedKeys.getInt(1);
                                JOptionPane.showMessageDialog(null, "The patron has been successfully added with the ID: " + id);
                            } else {
                            	JOptionPane.showMessageDialog(null, "No id Obtained");
                            }
                        }
                    }

                } catch (Exception e1) {
                    e1.printStackTrace();
                }

                
                
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnNewButton.setBounds(203, 282, 89, 23);
        contentPane.add(btnNewButton);

        rdbtnNewRadioButton = new JRadioButton("Student");
        rdbtnNewRadioButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
        rdbtnNewRadioButton.setBounds(226, 191, 111, 23);
        contentPane.add(rdbtnNewRadioButton);

        rdbtnNewRadioButton_1 = new JRadioButton("Faculty");
        rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        rdbtnNewRadioButton_1.setBounds(346, 191, 81, 23);
        contentPane.add(rdbtnNewRadioButton_1);
        
        JRadioButton rdbtnNewRadioButton = new JRadioButton("New radio button");
        rdbtnNewRadioButton.setBounds(226, 191, 111, 23);
        contentPane.add(rdbtnNewRadioButton);
    }

   /* private String generateUniquePatronId() {
        Random random = new Random();
        int randomDigits;
        do {
            randomDigits = random.nextInt(9000) + 1000; // Generate a random 4-digit number
        } while (usedDigits.contains(randomDigits));

        usedDigits.add(randomDigits);
        return "p" + randomDigits;
    }*/
}