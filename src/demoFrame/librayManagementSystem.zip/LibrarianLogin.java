package demoFrame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LibrarianLogin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField text_libID;
	private JTextField text_pwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LibrarianLogin frame = new LibrarianLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LibrarianLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 547, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label_libLogin = new JLabel("Librarian Login");
		label_libLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		label_libLogin.setBounds(202, 51, 168, 45);
		contentPane.add(label_libLogin);
		
		JLabel label_libID = new JLabel("Enter Librarian ID");
		label_libID.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_libID.setBounds(117, 170, 111, 45);
		contentPane.add(label_libID);
		
		JLabel label_pwd = new JLabel("Enter Password");
		label_pwd.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_pwd.setBounds(117, 268, 111, 33);
		contentPane.add(label_pwd);
		
		text_libID = new JTextField();
		text_libID.setBounds(287, 177, 126, 32);
		contentPane.add(text_libID);
		text_libID.setColumns(10);
		
		text_pwd = new JTextField();
		text_pwd.setBounds(287, 269, 126, 32);
		contentPane.add(text_pwd);
		text_pwd.setColumns(10);
		
		JButton button_login = new JButton("Login");
		button_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//authenticate librarian
			}
		});
		button_login.setFont(new Font("Tahoma", Font.PLAIN, 13));
		button_login.setBounds(202, 361, 112, 33);
		contentPane.add(button_login);
	}

}
