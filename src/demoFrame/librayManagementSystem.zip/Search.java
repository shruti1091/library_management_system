package demoFrame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Search extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField text_title;
    private JTextField text_author;

 

    // JFrame to display search results
    private JFrame resultFrame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Search frame = new Search();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Search() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 547, 496);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel label_heading = new JLabel("Search by book title or author");
        label_heading.setFont(new Font("Tahoma", Font.PLAIN, 20));
        label_heading.setBounds(142, 46, 287, 60);
        contentPane.add(label_heading);

        JLabel label_title = new JLabel("Title");
        label_title.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label_title.setBounds(147, 164, 70, 46);
        contentPane.add(label_title);

        JLabel label_author = new JLabel("Author");
        label_author.setFont(new Font("Tahoma", Font.PLAIN, 15));
        label_author.setBounds(142, 251, 70, 46);
        contentPane.add(label_author);

        text_title = new JTextField();
        text_title.setBounds(259, 174, 119, 31);
        contentPane.add(text_title);
        text_title.setColumns(10);

        text_author = new JTextField();
        text_author.setBounds(259, 261, 119, 31);
        contentPane.add(text_author);
        text_author.setColumns(10);

        JButton button_search = new JButton("Search");
        button_search.setFont(new Font("Tahoma", Font.PLAIN, 14));
        button_search.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = text_title.getText();
                String author = text_author.getText();

                // Call a method to fetch data based on the search criteria
                searchBooks(title, author);
            }
        });
        button_search.setBounds(199, 363, 119, 46);
        contentPane.add(button_search);
    }

    // Method to search for books based on title and author
    private void searchBooks(String title, String author) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb", "root", "harishruti"); 
            StringBuilder sql = new StringBuilder("SELECT * FROM LibraryBooks WHERE ");
            boolean hasTitle = !title.trim().isEmpty();
            boolean hasAuthor = !author.trim().isEmpty();
            
            if (hasTitle) {
                sql.append("title LIKE ?");
            }
            
            if (hasAuthor) {
                if (hasTitle) {
                    sql.append(" OR ");
                }
                sql.append("author LIKE ?");
            }
            
            if (!hasTitle && !hasAuthor) {
                return; // Do nothing if both fields are empty
            }

            PreparedStatement preparedStatement = con.prepareStatement(sql.toString());

            if (hasTitle) {
                preparedStatement.setString(1, "%" + title + "%");
            }
            
            if (hasAuthor) {
                preparedStatement.setString(hasTitle ? 2 : 1, "%" + author + "%");
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            
            if (!resultSet.isBeforeFirst()) {
                // No data, show error message
                JOptionPane.showMessageDialog(null, "No books found with the given criteria.");
                return;
            }

            // Create a new JFrame to display the search results
            resultFrame = new JFrame("Search Results");
            resultFrame.setBounds(100, 100, 600, 400);
            resultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            resultFrame.getContentPane().setLayout(new BorderLayout());

            // Create a JTable to display the search results
            JTable table = new JTable(buildTableModel(resultSet));
            JScrollPane scrollPane = new JScrollPane(table);
            resultFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);

            // Show the search results JFrame
            resultFrame.setVisible(true);

            resultSet.close();
            preparedStatement.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Helper method to convert ResultSet to DefaultTableModel for JTable
    private DefaultTableModel buildTableModel(ResultSet resultSet) {
        try {
            // Get metadata about the ResultSet
            java.sql.ResultSetMetaData metaData = resultSet.getMetaData();

            // Get the number of columns in the ResultSet
            int columnCount = metaData.getColumnCount();

            // Create a DefaultTableModel with column names
            DefaultTableModel tableModel = new DefaultTableModel();

            // Add column names to the tableModel
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                tableModel.addColumn(metaData.getColumnLabel(columnIndex));
            }

            // Add data rows to the tableModel
            while (resultSet.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    rowData[i] = resultSet.getObject(i + 1);
                }
                tableModel.addRow(rowData);
            }

            return tableModel;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}